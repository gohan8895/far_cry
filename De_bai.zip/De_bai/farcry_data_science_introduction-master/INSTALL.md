# Far Cry Multiplayer Configuration

## Settings

```text
log_FileVerbosity = "3"
```

## Multiplayer Match

The player that create the multiplayer session MUST join this session, either as a player or a spectator, in order Far Cry engine to log all the frags. 
